class Int1:
    def __init__(int):
        pass

class Int2:
    def __init__(int):
        pass

class Int3:
    def __init__(int):
        pass

class Int4:
    def __init__(int):
        pass

class Float1:
    def __init__(float):
        pass

class Float2:
    def __init__(float):
        pass

class Float3:
    def __init__(float):
        pass


class Img:
    def __init__(ndarray):
        pass
    
class Img1:
    def __init__(ndarray):
        pass
    
class Img2:
    def __init__(ndarray):
        pass

class Img3:
    def __init__(ndarray):
        pass
    
class Vector:
    def __init__(ndarray):
        pass
    
class Vector1:
    def __init__(ndarray):
        pass
