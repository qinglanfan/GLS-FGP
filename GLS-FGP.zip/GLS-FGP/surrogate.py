from deap import gp
import itertools
import collections
# import pandas as pd
import statistics
import numpy as np
from sklearn.svm import LinearSVC
import gp_tree
from sklearn import preprocessing
from sklearn.model_selection import cross_val_predict


def extract_features(ind: gp.PrimitiveTree, pset: gp.PrimitiveSetTyped, train_instance, train_label, toolbox_surrogate):
    """ Extracts the features from the individual

    :param ind: the individual
    :param pset: the primitive set used by the individual
    :return: the extracted features as pandas dataframe
    """
    # the first type of features---the max, min, and mean fitness value of parents
    pfit_min = np.nan
    pfit_max = np.nan
    pfit_avg = np.nan
    if hasattr(ind, 'parfitness'):
        pfit = ind.parfitness
        pfit_min = min(pfit)
        pfit_max = max(pfit)
        pfit_avg = statistics.mean(pfit)
    pfit_stats = [pfit_min, pfit_max, pfit_avg]
    # the second type of features---class labels of a small number of instances
    try:
        func_surrogate = toolbox_surrogate.compile(expr=ind)
        train_tf = []
        for i in range(0, len(train_label)):
            train_tf.append(np.asarray(func_surrogate(train_instance[i])))
        train_tf = np.asarray(train_tf, dtype=float)
        min_max_scaler = preprocessing.MinMaxScaler()
        train_norm = min_max_scaler.fit_transform(train_tf)
        lsvm = LinearSVC()
        y_predict = cross_val_predict(lsvm, train_norm, train_label, cv=3)
    except:
        y_predict = np.zeros(len(train_label))
        # print('y_predict', y_predict)
    # print(y_train)
    # print(y_predict)
    # print('*************************************************************')
    surrogate_data = np.concatenate((pfit_stats, y_predict, [len(ind), ind.height]), axis=0)
    return surrogate_data
