from deap import tools
import random
import surrogate
# import pandas as pd
from sklearn import ensemble, pipeline, preprocessing, svm, impute, neighbors
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.tree import DecisionTreeRegressor
import numpy as np
# import joblib
# import logging
from collections import defaultdict, deque


def pop_compare(ind1, ind2):
    # List all available primitive types in each individual
    types1 = defaultdict(list)
    types2 = defaultdict(list)
    for idx, node in enumerate(ind1[1:], 1):
        types1[node.ret].append(idx)
    for idx, node in enumerate(ind2[1:], 1):
        types2[node.ret].append(idx)
    return types1 == types2


def varAnd(population, toolbox, cxpb, mutpb):
    offspring = [toolbox.clone(ind) for ind in population]
    new_cxpb = cxpb/(cxpb+mutpb)
    for off in offspring:
        if hasattr(off, 'parfitness'):
            del off.parfitness
    # Apply crossover and mutation on the offspring
    i = 1
    while i < len(offspring):
        if random.random() < new_cxpb:
            if (offspring[i - 1] == offspring[i]) or pop_compare(offspring[i - 1], offspring[i]):
                offspring[i - 1], = toolbox.mutate(offspring[i - 1])
                offspring[i], = toolbox.mutate(offspring[i])
                del offspring[i-1].fitness.values, offspring[i].fitness.values
                # parent fitness-related features
                if not hasattr(offspring, 'parfitness'):
                    offspring[i-1].parfitness = [population[i-1].fitness.values[0]]
                    offspring[i].parfitness = [population[i].fitness.values[0]]
            else:
                offspring[i - 1], offspring[i] = toolbox.mate(offspring[i - 1], offspring[i])
                del offspring[i - 1].fitness.values, offspring[i].fitness.values
                # parent fitness-related features
                offspring[i - 1].parfitness = [population[i - 1].fitness.values[0], population[i].fitness.values[0]]
                offspring[i].parfitness = [population[i - 1].fitness.values[0], population[i].fitness.values[0]]
            i = i+2
        else:
            offspring[i], = toolbox.mutate(offspring[i])
            del offspring[i].fitness.values
            # parent fitness-related features
            if not hasattr(offspring, 'parfitness'):
                offspring[i].parfitness = [population[i].fitness.values[0]]
            i = i+1
    return offspring


def add_features(ind, pset, x_train, y_train, toolbox):
    """ Extracts the features from the individual and adds them a new field called 'features' created in the individual

    :param ind: the individual to extract features from
    :param pset: the primitive set used by the individual
    :return: the individual with added features
    """
    ind.features = surrogate.extract_features(ind, pset, x_train, y_train, toolbox)
    return ind


def feature_con(ind, add_0):
    ind.features = np.concatenate((ind.features, add_0), axis=0)
    return ind


# revised fitness evaluation/approximation
def ea_surrogate_is(x_train, y_train, population, toolbox, cxpb, mutpb, elitpb, max_evals, pset, stats=None,
                        halloffame=None, verbose=__debug__):
    # instance_selection(x_train)
    logbook = tools.Logbook()
    logbook.header = ['gen', 'nevals', 'tot_evals'] + (stats.fields if stats else [])
    # the first generation
    # Evaluate the individuals with an invalid fitness
    invalid_ind = [ind for ind in population if not ind.fitness.valid]
    fitnesses = toolbox.mapp(toolbox.evaluate, invalid_ind)
    for ind, fit in zip(population, fitnesses):
        ind.fitness.values = fit
        ind.estimate = False
        ind.parfitness = [fit[0]]
        add_features(ind, pset, x_train, y_train, toolbox)
    # add the evaluated individuals into archive
    archive = []
    for i in invalid_ind:
        if i.fitness.values[0] != 0.0:
            archive.append(i)
    # update the hall of fame
    if halloffame is not None:
        halloffame.update(population)
    hof_store = tools.HallOfFame(6 * len(population))
    hof_store.update(population)
    record = stats.compile(population) if stats else {}
    n_evals = len(invalid_ind)
    logbook.record(gen=0, nevals=len(population), tot_evals=n_evals,  **record)
    print(logbook.stream)
    best_ind_gen = []
    best_ind_gen.append(halloffame[0])
    gen = 1
    # Begin the generational process
    flag = 1
    while gen < max_evals+1:
        # Select the next generation individuals
        # elitism
        elitismNum = int(elitpb * len(population))
        population_for_eli = [toolbox.clone(ind) for ind in population]
        offspringE = toolbox.selectElitism(population_for_eli, k=elitismNum)
        # crossover and mutation
        offspring = toolbox.select(population, len(population) - elitismNum)
        offspring = varAnd(offspring, toolbox, cxpb, mutpb)
        # use subtree caching to find the fitness values for the same individual
        # being evaluated in the past
        # hash table (cache_table)
        # the fitness values of the individuals are assigned if they are in cache_table
        invalid_ind = [ind for ind in offspring if not ind.fitness.valid]
        for i in invalid_ind:
            ind = 0
            while ind < len(hof_store):
                if i == hof_store[ind]:
                    i.fitness.values = hof_store[ind].fitness.values
                    i.estimate = False
                    ind = len(hof_store)
                else:
                    ind += 1
        # surrogate model to predict the fitness values
        if flag == 1:
            print('global model--------')
            # global surrogate model
            if len(archive) >= 1000:
                train = random.sample(archive, 1000)
            else:
                train = archive
            # for i in range(0, len(train)):
            #     print('train[i].fitness.values[0]:', train[i].fitness.values[0])
            # surrogate training dataset (features_df) and targets (corresponding fitness values)
            features_df = [ind.features for ind in train if ind.fitness.values[0] < 1000]
            targets = [ind.fitness.values[0] for ind in train if ind.fitness.values[0] < 1000]
            # train the surrogate model using random forest Regressor
            clf = pipeline.Pipeline([('impute', impute.SimpleImputer(strategy='median')),
                                     ('model', ensemble.RandomForestRegressor(
                                         n_estimators=100, max_depth=14))])
            clf.fit(features_df, targets)
            # build surrogate test dataset
            invalid_ind = [add_features(ind, pset, x_train, y_train, toolbox)
                           for ind in offspring if not ind.fitness.valid]
            invalid_ix = [ind for ind in offspring if not ind.fitness.valid]
            pred_x = [ind.features for ind in invalid_ind]
            # pred_x_norm = min_max_scaler.transform(pred_x)
            # print('pred_x_norm', pred_x_norm)
            # Evaluate the individuals with an invalid fitness using the surrogate model
            preds = clf.predict(pred_x)
            # print('preds', preds)
            # select 1/3 best individuals
            sorted_ix = np.argsort(preds)
            # evaluate bad offspring using predicted values
            bad_ix = sorted_ix[0:int(2 * len(invalid_ind) / 3)]
            for ix in range(len(bad_ix)):
                invalid_ix[bad_ix[ix]].fitness.values = (preds[bad_ix[ix]],)
                invalid_ix[bad_ix[ix]].estimate = True
            # the rest of the individuals is evaluated using real evaluation
            invalid_ind = [ind for ind in offspring if not ind.fitness.valid]
            fitnesses = toolbox.mapp(toolbox.evaluate, invalid_ind)
            new_fitness = []
            for ind, fit in zip(invalid_ind, fitnesses):
                ind.fitness.values = fit
                new_fitness.append(fit)
                ind.estimate = False
                # print('ind.features', ind.features)
                # add_features(ind, pset, x_train, y_train, toolbox)
            if max(new_fitness) > max(targets):
                flag = 1
            else:
                flag = 0
            # add the evaluated individual into the archive
            for i in invalid_ind:
                if i.fitness.values[0] != 0.0:
                    archive.append(i)
        else:
            print('local model--------')
            # local surrogate model
            train = []
            fitnesses_archive = [ind.fitness.values[0] for ind in archive]
            sorted_ix = np.argsort(fitnesses_archive)
            print('fitness_archive', fitnesses_archive)
            selected_ix = sorted_ix[-int(1 * len(archive) / 10):]
            for ix in range(len(selected_ix)):
                train.append(archive[selected_ix[ix]])
            features_df = [ind.features for ind in train if ind.fitness.values[0] < 1000]
            targets = [ind.fitness.values[0] for ind in train if ind.fitness.values[0] < 1000]
            print('targets', targets)
            # train the surrogate model using random forest Regressor
            clf = pipeline.Pipeline([('impute', impute.SimpleImputer(strategy='median')),
                                     ('model', ensemble.RandomForestRegressor(
                                         n_estimators=100, max_depth=14))])
            clf.fit(features_df, targets)
            # build surrogate test dataset
            invalid_ind = [add_features(ind, pset, x_train, y_train, toolbox)
                           for ind in offspring if not ind.fitness.valid]
            invalid_ix = [ind for ind in offspring if not ind.fitness.valid]
            pred_x = [ind.features for ind in invalid_ind]
            # pred_x_norm = min_max_scaler.transform(pred_x)
            # Evaluate the individuals with an invalid fitness using the surrogate model
            preds = clf.predict(pred_x)
            print('pred', preds)
            # select 1/3 best individuals
            sorted_ix = np.argsort(preds)
            # evaluate bad offspring using predicted values
            bad_ix = sorted_ix[0:int(2 * len(invalid_ind) / 3)]
            print('len(bad_ix)', len(bad_ix))
            for ix in range(len(bad_ix)):
                invalid_ix[bad_ix[ix]].fitness.values = (preds[bad_ix[ix]],)
                print('preds[bad_ix[ix]]', preds[bad_ix[ix]])
                invalid_ix[bad_ix[ix]].estimate = True
            # the rest of the individuals is evaluated using real evaluation
            invalid_ind = [ind for ind in offspring if not ind.fitness.valid]
            fitnesses = toolbox.mapp(toolbox.evaluate, invalid_ind)
            new_fitness = []
            for ind, fit in zip(invalid_ind, fitnesses):
                ind.fitness.values = fit
                new_fitness.append(fit)
                ind.estimate = False
                # print('ind.features', ind.features)
                # add_features(ind, pset, x_train, y_train, toolbox)
            if max(new_fitness) > max(targets):
                flag = 0
            else:
                flag = 1
            # add the evaluated individual into the archive
            for i in invalid_ind:
                if i.fitness.values[0] != 0.0:
                    archive.append(i)
        # Update the hall of fame with the generated and evaluated individuals
        if halloffame is not None:
            halloffame.update(offspring)
        best_ind_gen.append(halloffame[0])
        # Replace the current population by the offspring
        hof_store.update(invalid_ind)
        population[:] = offspring
        population[0:0] = offspringE
        # Append the current generation statistics to the logbook
        evaluated = [ind for ind in population if not ind.estimate]
        record = stats.compile(evaluated) if stats else {}
        logbook.record(gen=gen, nevals=len(invalid_ind), tot_evals=n_evals, **record)
        gen += 1
        print(logbook.stream)
    return population, logbook

