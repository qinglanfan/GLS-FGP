import numpy as np
# import feature_function as fe_fs
from sklearn.model_selection import train_test_split
from sklearn.metrics import pairwise_distances
from sklearn.svm import SVC
import random
from sklearn.cluster import KMeans
from sklearn import preprocessing
from sklearn.neighbors import KNeighborsClassifier
from scipy.spatial import distance
from scipy import misc
from sklearn.cluster import KMeans, MiniBatchKMeans
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis


def image_selection(x_train, y_train, pr):
    x_train = x_train.reshape(x_train.shape[0], x_train.shape[1] * x_train.shape[2])
    min_max_scaler = preprocessing.StandardScaler()
    x_train = min_max_scaler.fit_transform(np.asarray(x_train))
    pca = LinearDiscriminantAnalysis()
    xt_train = pca.fit_transform(x_train, y_train)
    x_select_index = clutering(xt_train, y_train, pr)
    return x_select_index

def clutering(x_train, y_train, pr):
    x_train_select = []
    num_clusters = int(0.5 * pr * x_train.shape[0])
    #print(num_clusters)
    km = MiniBatchKMeans(n_clusters=num_clusters, max_iter=100)
    km.fit(x_train)
    cluster = km.predict(x_train)
    for i in range(num_clusters):
        x_clusters_index, = np.where(cluster == i)
        y_clusters = y_train[x_clusters_index]
        n_select = int(pr * len(y_clusters))
        nc_unique = np.unique(y_clusters)
        #print(y_clusters)
        if n_select == 0:
            if len(x_clusters_index) > 1:
                x_select = random.sample(x_clusters_index.tolist(), 1)
                x_train_select.append(x_select[0])
        else:
            if len(nc_unique) == 1:
                x_select = random.sample(x_clusters_index.tolist(), n_select)
                for i in x_select:
                    x_train_select.append(i)
                #print('e', len(x_select))
            else:
                for j in nc_unique:
                    numb_nc_unique = x_clusters_index[np.where(y_clusters == j)]
                    num_c = len(numb_nc_unique)
                    num_s = max(1, int(pr * num_c))
                    x_select = random.sample(numb_nc_unique.tolist(), num_s)
                    #print(len(x_select))
                    for i in x_select:
                        x_train_select.append(i)
    x_train_select = np.asarray(x_train_select, dtype='int')
    x_train_select = np.unique(x_train_select)
    return x_train_select
